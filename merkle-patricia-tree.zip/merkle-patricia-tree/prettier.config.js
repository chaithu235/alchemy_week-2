module.exports = require('@ethereumjs/eslint-config-defaults/prettier.config.js')
